<?php

include "header.php";
include "sidebar.php";
include "content.php";
include "footer.php";

?>